Thank you for giving Opportunity in to create this Website,

I have created Simple website with Login and Logout with Contact us page
and added Project file on Github

Step1: Download Project file[signup] from github

Step2: Import it in Eclipse.

Requirement:
Eclipse
Tomcat Server 8.5
MySql DB